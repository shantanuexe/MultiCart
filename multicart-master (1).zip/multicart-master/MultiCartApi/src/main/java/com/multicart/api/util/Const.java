package com.multicart.api.util;

public interface Const {

    interface OrderStatus {
            String IN_TRANSIT = "In Transit";
            String DELIVERED = "Delivred";
            String CANCELLED = "Cancelled";
    }
}
