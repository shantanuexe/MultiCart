package com.multicart.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MultiCartApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
